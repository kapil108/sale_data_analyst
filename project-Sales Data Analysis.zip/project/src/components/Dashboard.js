export function createDashboard(data) {
  return `
    <div class="container">
      <h1>Sales Analysis Dashboard</h1>
      
      <div class="metrics">
        <div class="metric">
          <h3>Total Sales</h3>
          <p id="totalSales"></p>
        </div>
        <div class="metric">
          <h3>Average Sale</h3>
          <p id="avgSale"></p>
        </div>
      </div>

      <div class="charts">
        <div class="chart-container">
          <h3>Daily Sales Trend</h3>
          <canvas id="salesTrend"></canvas>
        </div>
        <div class="chart-container">
          <h3>Top Products</h3>
          <canvas id="topProducts"></canvas>
        </div>
      </div>
    </div>
  `;
}