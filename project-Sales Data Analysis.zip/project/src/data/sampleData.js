export const sampleData = [
  { date: '2023-01-01', product: 'Product A', amount: 100 },
  { date: '2023-01-01', product: 'Product B', amount: 150 },
  { date: '2023-01-02', product: 'Product A', amount: 200 }
];