import { 
  calculateTotalSales, 
  calculateAverageSale, 
  groupSalesByDate,
  findTopProducts 
} from './utils/dataProcessor.js';
import { 
  createSalesChart, 
  createTopProductsChart 
} from './utils/visualization.js';

// Sample data - replace with your actual data source
const sampleData = [
  { date: '2023-01-01', product: 'Product A', amount: 100 },
  { date: '2023-01-01', product: 'Product B', amount: 150 },
  { date: '2023-01-02', product: 'Product A', amount: 200 },
  // Add more data as needed
];

document.querySelector('#app').innerHTML = `
  <div class="container">
    <h1>Sales Analysis Dashboard</h1>
    
    <div class="metrics">
      <div class="metric">
        <h3>Total Sales</h3>
        <p id="totalSales"></p>
      </div>
      <div class="metric">
        <h3>Average Sale</h3>
        <p id="avgSale"></p>
      </div>
    </div>

    <div class="charts">
      <div class="chart-container">
        <h3>Daily Sales Trend</h3>
        <canvas id="salesTrend"></canvas>
      </div>
      <div class="chart-container">
        <h3>Top Products</h3>
        <canvas id="topProducts"></canvas>
      </div>
    </div>
  </div>
`;

// Calculate metrics
document.getElementById('totalSales').textContent = 
  `$${calculateTotalSales(sampleData).toFixed(2)}`;
document.getElementById('avgSale').textContent = 
  `$${calculateAverageSale(sampleData).toFixed(2)}`;

// Create charts
const salesByDate = groupSalesByDate(sampleData);
const topProducts = findTopProducts(sampleData);

createSalesChart(
  document.getElementById('salesTrend'),
  salesByDate
);

createTopProductsChart(
  document.getElementById('topProducts'),
  topProducts
);