import './style.css';
import { createDashboard } from './components/Dashboard.js';
import { sampleData } from './data/sampleData.js';
import { initializeDashboard } from './services/dashboardService.js';

// Initialize the app
document.querySelector('#app').innerHTML = createDashboard(sampleData);
initializeDashboard(sampleData);