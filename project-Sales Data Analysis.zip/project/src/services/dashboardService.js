import { 
  calculateTotalSales, 
  calculateAverageSale, 
  groupSalesByDate,
  findTopProducts 
} from '../utils/dataProcessor.js';

import { 
  createSalesChart, 
  createTopProductsChart 
} from '../utils/visualization.js';

export function initializeDashboard(data) {
  // Update metrics
  document.getElementById('totalSales').textContent = 
    `$${calculateTotalSales(data).toFixed(2)}`;
  document.getElementById('avgSale').textContent = 
    `$${calculateAverageSale(data).toFixed(2)}`;

  // Create charts
  const salesByDate = groupSalesByDate(data);
  const topProducts = findTopProducts(data);

  createSalesChart(
    document.getElementById('salesTrend'),
    salesByDate
  );

  createTopProductsChart(
    document.getElementById('topProducts'),
    topProducts
  );
}