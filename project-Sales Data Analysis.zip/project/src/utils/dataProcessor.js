import { parseISO, format } from 'date-fns';

export function calculateTotalSales(data) {
  return data.reduce((total, sale) => total + sale.amount, 0);
}

export function calculateAverageSale(data) {
  return data.length ? calculateTotalSales(data) / data.length : 0;
}

export function groupSalesByDate(data) {
  return data.reduce((acc, sale) => {
    const date = format(parseISO(sale.date), 'yyyy-MM-dd');
    acc[date] = (acc[date] || 0) + sale.amount;
    return acc;
  }, {});
}

export function findTopProducts(data) {
  const productSales = data.reduce((acc, sale) => {
    acc[sale.product] = (acc[sale.product] || 0) + sale.amount;
    return acc;
  }, {});
  
  return Object.entries(productSales)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);
}