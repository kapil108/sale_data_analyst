import Chart from 'chart.js/auto';

export function createSalesChart(ctx, data) {
  return new Chart(ctx, {
    type: 'line',
    data: {
      labels: Object.keys(data),
      datasets: [{
        label: 'Daily Sales',
        data: Object.values(data),
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: 'Sales Amount ($)'
          }
        },
        x: {
          title: {
            display: true,
            text: 'Date'
          }
        }
      }
    }
  });
}

export function createTopProductsChart(ctx, data) {
  return new Chart(ctx, {
    type: 'bar',
    data: {
      labels: data.map(([product]) => product),
      datasets: [{
        label: 'Sales by Product',
        data: data.map(([, amount]) => amount),
        backgroundColor: 'rgb(54, 162, 235)'
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: 'Sales Amount ($)'
          }
        }
      }
    }
  });
}